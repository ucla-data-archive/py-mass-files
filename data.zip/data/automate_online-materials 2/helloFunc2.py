def hello(name):
    print('Hello ' + name)

hello('Alice')
hello('Bob')
